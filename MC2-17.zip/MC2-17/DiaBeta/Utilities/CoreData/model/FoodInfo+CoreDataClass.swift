//
//  FoodInfo+CoreDataClass.swift
//  DiaBeta
//
//  Created by Vincentius Ian Widi Nugroho on 18/06/22.
//
//

import Foundation
import CoreData

@objc(FoodInfo)
public class FoodInfo: NSManagedObject {

}
