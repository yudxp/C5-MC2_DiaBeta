//
//  DummyViewController.swift
//  DiaBeta
//
//  Created by Vincentius Ian Widi Nugroho on 10/06/22.
//

import UIKit

class DummyViewController: UIViewController {

  override func viewDidLoad() {
    super.viewDidLoad()
    // Do any additional setup after loading the view.
  }


}
