# MC2-17
Diabeta
Aplikasi untuk menolong orang yang memiliki diabetes
